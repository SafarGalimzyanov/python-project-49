#!/usr/bin/env python3

from brain_games.brain_even_logic import even_game 


def main():
    print('Welcome to the Brain Games!')
    even_game()


if __name__ == '__main__':
    main()
