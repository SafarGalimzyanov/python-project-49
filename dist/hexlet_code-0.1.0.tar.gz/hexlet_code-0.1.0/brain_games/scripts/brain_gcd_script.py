
    game_rule = 'Find the greatest common divisor of given numbers.'

 
