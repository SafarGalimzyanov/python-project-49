    game_rule = 'What number is missing in the progression?'

    num_of_elems = 10
 
