### Hexlet tests and linter status:
[![Actions Status](https://github.com/SafarGalimzyanov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SafarGalimzyanov/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/566304b06d2e1648d868/maintainability)](https://codeclimate.com/github/SafarGalimzyanov/python-project-49/maintainability)
[![Asciinema]](https://asciinema.org/a/zZxxmOvXDh7Tde3xq3YhJww9i)
